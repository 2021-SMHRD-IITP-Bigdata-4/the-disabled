 
select * from building_enroll where bui_name = '�׸��Ѽֺ�'

select * from POINT_TB

select * from BUILDING_ENROLL where bui_no = '3895'
select * from BUILDING_ENROLL where bui_name like '%�޸սþ�%';