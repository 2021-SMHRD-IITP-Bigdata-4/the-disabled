package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WebAlrimDAO {

	PreparedStatement psmt = null;
	Connection conn = null;
	int cnt = 0;
	ResultSet rs = null;
	WebAlrimDTO dto = null;
	ArrayList<WebAlrimDTO> list = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e6";
			String db_pw = "smhrd6";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if(psmt != null){
				psmt.close();
			}			
			if(conn != null){
				conn.close();
			}		
		} catch (SQLException e) {
			e.printStackTrace();

		}	
	}
	
	public ArrayList<WebAlrimDTO> selectAll() {
		conn();
		
		String sql = "select * from BUILDING_ENROLL order by bui_no desc";
		list = new ArrayList<WebAlrimDTO>();
		try {
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();

			for(int i = 0; i < 3; i++) {
				rs.next();
				int num = rs.getInt(1);
				String si= rs.getString(2);
				String gu= rs.getString(3);
				String dong = rs.getString(4);
				String name = rs.getString(6);
				Boolean parking = rs.getBoolean(13);
				Boolean slide = rs.getBoolean(14);
				Boolean aut = rs.getBoolean(15);
				Boolean rest = rs.getBoolean(16);
				Boolean elevate = rs.getBoolean(17);
				Boolean dot = rs.getBoolean(18);
				String date = rs.getString(10);
				String pic = rs.getString(7);
				dto = new WebAlrimDTO(num, si, gu, dong, name, parking, slide, aut, rest, elevate, dot, date, pic);
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	public ArrayList<WebAlrimDTO> selectAllS(String keyWord) {
		conn();
		
		String sql = "select * from BUILDING_ENROLL where bui_name like ?";
		list = new ArrayList<WebAlrimDTO>();
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, "%"+keyWord+"%");
			rs = psmt.executeQuery();
			rs.next();
			while(rs.next()) {
				int num = rs.getInt(1);
				String si= rs.getString(2);
				String gu= rs.getString(3);
				String dong = rs.getString(4);
				String name = rs.getString(6);
				Boolean parking = rs.getBoolean(13);
				Boolean slide = rs.getBoolean(14);
				Boolean aut = rs.getBoolean(15);
				Boolean rest = rs.getBoolean(16);
				Boolean elevate = rs.getBoolean(17);
				Boolean dot = rs.getBoolean(18);
				String date = rs.getString(10);
				String pic = rs.getString(7);
				dto = new WebAlrimDTO(num, si, gu, dong, name, parking, slide, aut, rest, elevate, dot, date, pic);
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
}
