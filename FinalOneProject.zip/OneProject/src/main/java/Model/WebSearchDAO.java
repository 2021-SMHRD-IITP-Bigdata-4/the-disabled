package Model;

public class WebSearchDAO {

}
