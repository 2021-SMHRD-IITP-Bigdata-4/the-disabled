package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WebReplyDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	WebReplyDTO sdto = null;
	ArrayList<WebReplyDTO> list = null; 
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e6";
			String db_pw = "smhrd6";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			if(rs!=null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
				}
			if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	public int insertBoard(WebReplyDTO dto) {
		conn();
		
		try {
			String sql = "insert into reply values(REPLY_SEQ.nextval, ?, ?, sysdate)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getRep_name());
			psmt.setString(2, dto.getRep_con());
			
			cnt = psmt.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return cnt;
		}
	
	public ArrayList<WebReplyDTO> selectAll() {
		conn();
		list = new ArrayList<WebReplyDTO>();
		try {
			String sql = "select * from reply";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				int rep_no = rs.getInt(1);
				String rep_name = rs.getString(2);
				String rep_con = rs.getString(3);
				String rep_date = rs.getString(4);
				
				sdto = new WebReplyDTO(rep_no, rep_name, rep_con, rep_date);
				list.add(sdto);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return list;
	}
}
