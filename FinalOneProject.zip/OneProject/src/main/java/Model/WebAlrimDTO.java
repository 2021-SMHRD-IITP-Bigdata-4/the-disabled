package Model;

public class WebAlrimDTO {

	private int num;
	private String si;
	private String gu;
	private String dong;
	private String name;
	private boolean parking;
	private boolean slide;
	private boolean aut;
	private boolean rest;
	private boolean elevate;
	private boolean dot;
	private String date;
	private String pic;
	
	
	
	public WebAlrimDTO(int num, String si, String gu, String dong, String name, boolean parking, boolean slide,
			boolean aut, boolean rest, boolean elevate, boolean dot, String date, String pic) {
		this.num = num;
		this.si = si;
		this.gu = gu;
		this.dong = dong;
		this.name = name;
		this.parking = parking;
		this.slide = slide;
		this.aut = aut;
		this.rest = rest;
		this.elevate = elevate;
		this.dot = dot;
		this.date = date;
		this.pic = pic;
	}	
	public WebAlrimDTO(String name, String si, String gu, String dong, boolean parking, boolean slide,
			boolean aut, boolean rest, boolean elevate, boolean dot, String date, String pic) {
		this.si = si;
		this.gu = gu;
		this.dong = dong;
		this.name = name;
		this.parking = parking;
		this.slide = slide;
		this.aut = aut;
		this.rest = rest;
		this.elevate = elevate;
		this.dot = dot;
		this.date = date;
		this.pic = pic;

	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isParking() {
		return parking;
	}
	public void setParking(boolean parking) {
		this.parking = parking;
	}
	public boolean isSlide() {
		return slide;
	}
	public void setSlide(boolean slide) {
		this.slide = slide;
	}
	public boolean isAut() {
		return aut;
	}
	public void setAut(boolean aut) {
		this.aut = aut;
	}
	public boolean isRest() {
		return rest;
	}
	public void setRest(boolean rest) {
		this.rest = rest;
	}
	public boolean isElevate() {
		return elevate;
	}
	public void setElevate(boolean elevate) {
		this.elevate = elevate;
	}
	public boolean isDot() {
		return dot;
	}
	public void setDot(boolean dot) {
		this.dot = dot;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}

	
	
}
