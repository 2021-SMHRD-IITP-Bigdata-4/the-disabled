package Model;

public class WebEnrollDTO {

	private int num;
	private String si;
	private String gu;
	private String dong;
	private String info1;
	private String name;
	private String pic;
	private String wi;
	private String gyeo;
	private String date;
	private int[] nums;
	private String email;
	
	
	public WebEnrollDTO(String si, String gu, String dong, String info1, String name, int[] nums, String email) {
		super();
		this.si = si;
		this.gu = gu;
		this.dong = dong;
		this.info1 = info1;
		this.name = name;
		this.nums = nums;
		this.email = email;
	}

	public WebEnrollDTO(int num, String si, String gu, String dong, String info1, String name, String pic, String wi,
			String gyeo, String date, int[] nums, String email) {
		super();
		this.num = num;
		this.si = si;
		this.gu = gu;
		this.dong = dong;
		this.info1 = info1;
		this.name = name;
		this.pic = pic;
		this.wi = wi;
		this.gyeo = gyeo;
		this.date = date;
		this.nums = nums;
		this.email = email;
	}	
	
	public WebEnrollDTO( String si, String gu, String dong, String info1, String name, String pic, 
			  int[] nums, String email) {

		this.si = si;
		this.gu = gu;
		this.dong = dong;
		this.info1 = info1;
		this.name = name;
		this.pic = pic;
		this.nums = nums;
		this.email = email;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getInfo1() {
		return info1;
	}
	public void setInfo1(String info1) {
		this.info1 = info1;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getWi() {
		return wi;
	}
	public void setWi(String wi) {
		this.wi = wi;
	}
	public String getGyeo() {
		return gyeo;
	}
	public void setGyeo(String gyeo) {
		this.gyeo = gyeo;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int[] getNums() {
		return nums;
	}
	public void setNums(int[] nums) {
		this.nums = nums;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
}
