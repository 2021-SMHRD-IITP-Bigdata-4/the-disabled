package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WebEnrollDAO {

	

	PreparedStatement psmt = null;
	Connection conn = null;
	int cnt = 0;
	ResultSet rs = null;
	WebAlrimDTO dto = null;
	ArrayList<WebAlrimDTO> list = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e6";
			String db_pw = "smhrd6";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if(psmt != null){
				psmt.close();
			}			
			if(conn != null){
				conn.close();
			}		
		} catch (SQLException e) {
			e.printStackTrace();

		}	
	}
	//si, gu, dong, info1, name, pic, nums, email
	public int enroll(WebEnrollDTO dto) {
		conn();
		try {
			String sql = "insert into BUILDING_ENROLL values(3896,?,?,?,?,?,0,0,0,sysdate,0,?,?,?,?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getSi());
			psmt.setString(2, dto.getGu());
			psmt.setString(3, dto.getDong());
			psmt.setString(4, dto.getInfo1());
			psmt.setString(5, dto.getName());
		
			
			for(int i = 0; i < 6; i++) {
				if(dto.getNums()[i] == i+1) {
					psmt.setDouble(6+i, 1);
				}else {
					psmt.setDouble(6+i, 0);
				}
			}
			psmt.setString(12, dto.getEmail());


			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			close();
		}
		return cnt;
	}
}
