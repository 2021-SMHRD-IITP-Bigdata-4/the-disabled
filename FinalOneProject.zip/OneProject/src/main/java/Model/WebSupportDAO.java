package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class WebSupportDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	ResultSet rs = null;
	WebSupportDTO sdto = null;
	ArrayList<WebSupportDTO> list = null; 
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e6";
			String db_pw = "smhrd6";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			if(rs!=null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
				}
			if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	public int insertBoard(WebNoticeDTO dto) {
		conn();
		
		try {
			String sql = "insert into notice_tb values(NOTICE_SEQ.nextval, 6, ?, ?, sysdate)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getNotice_name());
			psmt.setString(2, dto.getNotice_con());
			
			cnt = psmt.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return cnt;
		}
	
	public ArrayList<WebSupportDTO> selectAll() {
		conn();
		list = new ArrayList<WebSupportDTO>();
		try {
			String sql = "select * from support_tb order by support_no desc";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				String support_no = rs.getString(1);
				String writer = rs.getString(2);
				String support_name = rs.getString(3);
				String support_agen = rs.getString(4);
				String support_goal = rs.getString(5);
				String support_tar = rs.getString(6);
				String support_con = rs.getString(7);
				String support_date = rs.getString(8);
				String support_sys = rs.getString(9);
				
				sdto = new WebSupportDTO(support_no, writer, support_name, support_agen, support_goal, support_tar, support_con, support_date, support_sys);		
				list.add(sdto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return list;
		
	}
	
	public WebSupportDTO selectOne(String num) {
		conn();
	
		try {
			String sql = "select * from support_tb where support_no = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, num);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				String support_no = rs.getString(1);
				String writer = rs.getString(2);
				String support_name = rs.getString(3);
				String support_agen = rs.getString(4);
				String support_goal = rs.getString(5);
				String support_tar = rs.getString(6);
				String support_con = rs.getString(7);
				String support_date = rs.getString(8);
				String support_sys = rs.getString(9);
				
				
				
				sdto = new WebSupportDTO(support_no, writer, support_name, support_agen, support_goal, support_tar, support_con, support_date, support_sys);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return sdto;
	}
}
