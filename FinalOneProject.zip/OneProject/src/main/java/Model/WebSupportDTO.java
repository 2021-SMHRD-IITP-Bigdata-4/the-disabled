package Model;

public class WebSupportDTO {
	private String support_no;
	private String writer;
	private String support_name;
	private String support_agen;
	private String support_goal;
	private String support_tar;
	private String support_con;
	private String support_date;
	private String support_sys;
	
	
	public WebSupportDTO(String support_no, String writer, String support_name, String support_agen, String support_goal,
			String support_tar, String support_con, String support_date, String support_sys) {
		
		this.support_no = support_no;
		this.writer = writer;
		this.support_name = support_name;
		this.support_agen = support_agen;
		this.support_goal = support_goal;
		this.support_tar = support_tar;
		this.support_con = support_con;
		this.support_date = support_date;
		this.support_sys = support_sys;
	}


	public String getSupport_no() {
		return support_no;
	}





	public void setSupport_no(String support_no) {
		this.support_no = support_no;
	}





	public String getWriter() {
		return writer;
	}


	public void setWriter(String writer) {
		this.writer = writer;
	}


	public String getSupport_name() {
		return support_name;
	}


	public void setSupport_name(String support_name) {
		this.support_name = support_name;
	}


	public String getSupport_agen() {
		return support_agen;
	}


	public void setSupport_agen(String support_agen) {
		this.support_agen = support_agen;
	}


	public String getSupport_goal() {
		return support_goal;
	}


	public void setSupport_goal(String support_goal) {
		this.support_goal = support_goal;
	}


	public String getSupport_tar() {
		return support_tar;
	}


	public void setSupport_tar(String support_tar) {
		this.support_tar = support_tar;
	}


	public String getSupport_con() {
		return support_con;
	}


	public void setSupport_con(String support_con) {
		this.support_con = support_con;
	}


	public String getSupport_date() {
		return support_date;
	}


	public void setSupport_date(String support_date) {
		this.support_date = support_date;
	}


	public String getSupport_sys() {
		return support_sys;
	}


	public void setSupport_sys(String support_sys) {
		this.support_sys = support_sys;
	}
	
	
	
	
}
