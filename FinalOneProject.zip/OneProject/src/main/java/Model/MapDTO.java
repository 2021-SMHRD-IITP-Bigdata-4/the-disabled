package Model;

public class MapDTO {
	private String bui_si;
	private String bui_gu;
	private String bui_dong;
	private String bui_name;
	private String bui_lati;
	private String bui_long;
	private int parking;
	private int slide;
	private int aut;
	private int rest;
	private int elevate;
	private int dot;
	
	public MapDTO(String bui_si, String bui_gu, String bui_dong, String bui_name, String bui_lati, String bui_long,
			int parking, int slide, int aut, int rest, int elevate, int dot) {
		super();
		this.bui_si = bui_si;
		this.bui_gu = bui_gu;
		this.bui_dong = bui_dong;
		this.bui_name = bui_name;
		this.bui_lati = bui_lati;
		this.bui_long = bui_long;
		this.parking = parking;
		this.slide = slide;
		this.aut = aut;
		this.rest = rest;
		this.elevate = elevate;
		this.dot = dot;
	}

	public void setBui_si(String bui_si) {
		this.bui_si = bui_si;
	}

	public void setBui_gu(String bui_gu) {
		this.bui_gu = bui_gu;
	}

	public void setBui_dong(String bui_dong) {
		this.bui_dong = bui_dong;
	}

	public void setBui_name(String bui_name) {
		this.bui_name = bui_name;
	}

	public void setBui_lati(String bui_lati) {
		this.bui_lati = bui_lati;
	}

	public void setBui_long(String bui_long) {
		this.bui_long = bui_long;
	}

	public void setParking(int parking) {
		this.parking = parking;
	}

	public void setSlide(int slide) {
		this.slide = slide;
	}

	public void setAut(int aut) {
		this.aut = aut;
	}

	public void setRest(int rest) {
		this.rest = rest;
	}

	public void setElevate(int elevate) {
		this.elevate = elevate;
	}

	public void setDot(int dot) {
		this.dot = dot;
	}

	public String getBui_si() {
		return bui_si;
	}

	public String getBui_gu() {
		return bui_gu;
	}

	public String getBui_dong() {
		return bui_dong;
	}

	public String getBui_name() {
		return bui_name;
	}

	public String getBui_lati() {
		return bui_lati;
	}

	public String getBui_long() {
		return bui_long;
	}

	public int getParking() {
		return parking;
	}

	public int getSlide() {
		return slide;
	}

	public int getAut() {
		return aut;
	}

	public int getRest() {
		return rest;
	}

	public int getElevate() {
		return elevate;
	}

	public int getDot() {
		return dot;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
