package Model;

public class WebReplyDTO {

	private int rep_no;
	private String rep_name;
	private String rep_con;
	private String rep_date;
	
	
	public WebReplyDTO(int rep_no, String rep_name, String rep_con, String rep_date) {
		this.rep_no = rep_no;
		this.rep_name = rep_name;
		this.rep_con = rep_con;
		this.rep_date = rep_date;
	}

	

	public WebReplyDTO(String rep_name, String rep_con) {
		this.rep_name = rep_name;
		this.rep_con = rep_con;
	}



	public int getRep_no() {
		return rep_no;
	}


	public void setRep_no(int rep_no) {
		this.rep_no = rep_no;
	}


	public String getRep_name() {
		return rep_name;
	}


	public void setRep_name(String rep_name) {
		this.rep_name = rep_name;
	}


	public String getRep_con() {
		return rep_con;
	}


	public void setRep_con(String rep_con) {
		this.rep_con = rep_con;
	}


	public String getRep_date() {
		return rep_date;
	}


	public void setRep_date(String rep_date) {
		this.rep_date = rep_date;
	}
	
	
}


