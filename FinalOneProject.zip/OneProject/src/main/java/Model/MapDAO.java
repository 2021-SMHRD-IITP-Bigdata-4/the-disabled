package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class MapDAO {
	
	PreparedStatement psmt = null;
	Connection conn = null;
	ResultSet rs = null;
	
	ArrayList<MapDTO> list = null;
	
	MapDTO dto = null;
	
	public void conn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@project-db-stu.ddns.net:1524:xe";
			String db_id = "campus_e6";
			String db_pw = "smhrd6";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if(psmt != null){
				psmt.close();
			}			
			if(conn != null){
				conn.close();
			}		
		} catch (SQLException e) {
			e.printStackTrace();

		}
		
	}

	public ArrayList<MapDTO> bukgu() {
		conn();
		list = new ArrayList<MapDTO>();	
		try {
			String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll "
					+ "where bui_gu like '�ϱ�'";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();			
			
			while(rs.next()) {
				String bui_si = rs.getString(1);
				String bui_gu = rs.getString(2);
				String bui_dong = rs.getString(3);
				String bui_name = rs.getString(4);
				String bui_lati = rs.getString(5);
				String bui_long = rs.getString(6);
				int parking = rs.getInt(7);
				int slide = rs.getInt(8);
				int aut = rs.getInt(9);
				int rest = rs.getInt(10);
				int elevate = rs.getInt(11);
				int dot = rs.getInt(12);
				
				dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
				
				list.add(dto);
			}	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();			
		}
		return list;
	}
	
	
		public ArrayList<MapDTO> donggu() {
			conn();
			list = new ArrayList<MapDTO>();
			
			try {
				String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_gu like '����'";
				psmt = conn.prepareStatement(sql);
				rs = psmt.executeQuery();			
				
				while(rs.next()) {
					String bui_si = rs.getString(1);
					String bui_gu = rs.getString(2);
					String bui_dong = rs.getString(3);
					String bui_name = rs.getString(4);
					String bui_lati = rs.getString(5);
					String bui_long = rs.getString(6);
					int parking = rs.getInt(7);
					int slide = rs.getInt(8);
					int aut = rs.getInt(9);
					int rest = rs.getInt(10);
					int elevate = rs.getInt(11);
					int dot = rs.getInt(12);
					
					dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
					
					list.add(dto);
					
	
					
					
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close();			
			}
			
			return list;
			
		}
		
		public ArrayList<MapDTO> namgu() {
			conn();
			list = new ArrayList<MapDTO>();
			
			try {
				String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_gu like '����'";
				psmt = conn.prepareStatement(sql);
				rs = psmt.executeQuery();			
				
				while(rs.next()) {
					String bui_si = rs.getString(1);
					String bui_gu = rs.getString(2);
					String bui_dong = rs.getString(3);
					String bui_name = rs.getString(4);
					String bui_lati = rs.getString(5);
					String bui_long = rs.getString(6);
					int parking = rs.getInt(7);
					int slide = rs.getInt(8);
					int aut = rs.getInt(9);
					int rest = rs.getInt(10);
					int elevate = rs.getInt(11);
					int dot = rs.getInt(12);
					
					dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
					
					list.add(dto);
					
					
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close();			
			}
			
			return list;
			
		}
		
		public ArrayList<MapDTO> seogu() {
			conn();
			list = new ArrayList<MapDTO>();
			
			try {
				String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_gu like '����'";
				psmt = conn.prepareStatement(sql);
				rs = psmt.executeQuery();			
				
				while(rs.next()) {
					String bui_si = rs.getString(1);
					String bui_gu = rs.getString(2);
					String bui_dong = rs.getString(3);
					String bui_name = rs.getString(4);
					String bui_lati = rs.getString(5);
					String bui_long = rs.getString(6);
					int parking = rs.getInt(7);
					int slide = rs.getInt(8);
					int aut = rs.getInt(9);
					int rest = rs.getInt(10);
					int elevate = rs.getInt(11);
					int dot = rs.getInt(12);
					
					dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
					
					list.add(dto);
					
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close();			
			}
			
			return list;
			
		}
		
		
	

	public ArrayList<MapDTO> gwangsangu() {
		conn();
		list = new ArrayList<MapDTO>();
		
		try {
			String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_gu like '���걸'";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();			
			
			while(rs.next()) {
				String bui_si = rs.getString(1);
				String bui_gu = rs.getString(2);
				String bui_dong = rs.getString(3);
				String bui_name = rs.getString(4);
				String bui_lati = rs.getString(5);
				String bui_long = rs.getString(6);
				int parking = rs.getInt(7);
				int slide = rs.getInt(8);
				int aut = rs.getInt(9);
				int rest = rs.getInt(10);
				int elevate = rs.getInt(11);
				int dot = rs.getInt(12);
				
				dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
				
				list.add(dto);
				
				
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();			
		}
		
		return list;
		
	}
	
	public ArrayList<MapDTO> Serach() {
		conn();
		list = new ArrayList<MapDTO>();
		
		try {
			String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_name like '%����%' ";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();			
			
			while(rs.next()) {
				String bui_si = rs.getString(1);
				String bui_gu = rs.getString(2);
				String bui_dong = rs.getString(3);
				String bui_name = rs.getString(4);
				String bui_lati = rs.getString(5);
				String bui_long = rs.getString(6);
				int parking = rs.getInt(7);
				int slide = rs.getInt(8);
				int aut = rs.getInt(9);
				int rest = rs.getInt(10);
				int elevate = rs.getInt(11);
				int dot = rs.getInt(12);
				
				dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
				
				list.add(dto);
				
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();			
		}
		
		return list;
		
	}
	
	public ArrayList<MapDTO> Serach2() {
		conn();
		list = new ArrayList<MapDTO>();
		
		try {
			String sql = "select bui_si,bui_gu,bui_dong,bui_name,bui_lati,bui_long,parking,slide,aut,rest,elevate,dot from building_enroll where bui_name like '%��Ʈ%' ";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();			
			
			while(rs.next()) {
				String bui_si = rs.getString(1);
				String bui_gu = rs.getString(2);
				String bui_dong = rs.getString(3);
				String bui_name = rs.getString(4);
				String bui_lati = rs.getString(5);
				String bui_long = rs.getString(6);
				int parking = rs.getInt(7);
				int slide = rs.getInt(8);
				int aut = rs.getInt(9);
				int rest = rs.getInt(10);
				int elevate = rs.getInt(11);
				int dot = rs.getInt(12);
				
				dto = new MapDTO(bui_si, bui_gu, bui_dong, bui_name, bui_lati, bui_long, parking, slide, aut, rest, elevate, dot);
				
				list.add(dto);
				
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();			
		}
		
		return list;
		
	}
	
	
	

	


}
