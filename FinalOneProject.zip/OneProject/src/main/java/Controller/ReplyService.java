package Controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.WebNoticeDAO;
import Model.WebNoticeDTO;
import Model.WebReplyDAO;
import Model.WebReplyDTO;


@WebServlet("/ReplyService")
public class ReplyService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("EUC-KR");
		request.setCharacterEncoding("utf-8");
		String rep_name = request.getParameter("rep_name");
		String rep_con = request.getParameter("rep_con");
		
		WebReplyDTO dto = new WebReplyDTO(rep_name, rep_con);
		WebReplyDAO dao =  new WebReplyDAO();
		
		int cnt = dao.insertBoard(dto);
		System.out.println(rep_name);
		if (cnt > 0) {
			System.out.println("�Խ����Է� ����");
		} else {
			System.out.println("�Խ����Է� ����");
		}
		response.sendRedirect("iLBiBuilding.jsp");
	
	}
	}


