package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import Model.MapDAO;
import Model.MapDTO;


@WebServlet("/BukGu")
public class BukGu extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setCharacterEncoding("utf-8");
		
		
		
		MapDAO dao = new MapDAO();
		MapDTO dto = null;
		
		ArrayList<MapDTO> list = dao.bukgu();
	
		
		Gson gson = new Gson();
		JsonArray jArray = new JsonArray();
		JsonParser parser = new JsonParser();
		
		for(int i=0; i<list.size(); i++) {
			dto =list.get(i);
			String jsonString = gson.toJson(dto);
			JsonObject jobj = null;
			try {
				jobj =  (JsonObject) parser.parse(jsonString);	
			}catch (Exception e) {
				e.printStackTrace();
			}			
			jArray.add(jobj);
			
		}
		
		PrintWriter out = response.getWriter();		
		out.print(jArray.toString());
	
		
		for(int i =0; i<list.size(); i++) {		
			System.out.println(list.get(i).getBui_si()+list.get(i).getBui_lati()+list.get(i).getBui_long());
			
		}
	}

}
