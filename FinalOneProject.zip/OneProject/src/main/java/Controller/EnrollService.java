package Controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import Model.WebEnrollDAO;
import Model.WebEnrollDTO;
import Model.WebMemberDAO;
import Model.WebMemberDTO;

/**
 * Servlet implementation class EnrollService
 */
@WebServlet("/EnrollService")
public class EnrollService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
	      WebMemberDTO info = (WebMemberDTO)session.getAttribute("info");
	      request.setCharacterEncoding("EUC-KR");
	      request.setCharacterEncoding("utf-8");
	      
	    

		
		String si = request.getParameter("bui_si");
		String gu = request.getParameter("bui_gu");
		String dong = request.getParameter("bui_dong");
		String info1 = request.getParameter("bui_info");
		String name = request.getParameter("bui_name");
		System.out.println("�ȴ�");
		System.out.println(name);
		System.out.println("gu");
		String[] arr = request.getParameterValues("safe[]");
		System.out.println(arr);
        int[] nums = Arrays.stream(arr).mapToInt(Integer::parseInt).toArray();
        System.out.println("�ȴ�3");
		String email = info.getEmail();
		System.out.println("�ȴ�2");
		Arrays.toString(nums);
		System.out.println(si);
		
		WebEnrollDTO dto = new WebEnrollDTO(si, gu, dong, info1, name, nums, email);
		WebEnrollDAO dao = new WebEnrollDAO();
		int cnt = dao.enroll(dto);

		if(cnt > 0) {
			System.out.println("����!");
		}else {
			System.out.println("����");
		}
		response.sendRedirect("iLBiMain.jsp");
	}

}
